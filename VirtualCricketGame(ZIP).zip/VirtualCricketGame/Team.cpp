#include "Team.h"		//<vector>, <string>, "player.h"

Team::Team() {
	
	totalRunsScored = 0;
	wicketsLost = 0;
	totalBallsBowled = 0;
}
